﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public int highPoint1;
    public static UIManager instance;
    public Text HighPoint1;
    void Start()
    {
        HighPoint1.text = "" + PlayerPrefs.GetInt("highscore").ToString(); 
    }
   
   
    void Update()
    {
           
    }

    public void Play()
    {
        SceneManager.LoadScene(1);
        AudioManager.instance.PlayAudio(3);
        
    }

    public void Restart()
    {
        SceneManager.LoadScene(1);
        AudioManager.instance.PlayAudio(3);
    
    }

    public void home()
    {
        SceneManager.LoadScene(0);
        AudioManager.instance.PlayAudio(3);
       
    }
}
